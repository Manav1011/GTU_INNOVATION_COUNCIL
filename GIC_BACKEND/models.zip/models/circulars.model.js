const mongoose = require('mongoose')

const Circular = mongoose.model("Circular",mongoose.Schema({
    title : {
        type : String,
        required : true
    },
    content : {
        type : String,
        required : true
    },
    circular_type : {
        type : String,
        required : true
    },
    date : {
        type : String,
        required : true
    },
    attechment : {
        type : String,
        required : true
    }
}))

module.exports = Circular