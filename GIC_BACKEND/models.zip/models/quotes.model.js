const mongoose = require('mongoose')

const Quote = mongoose.model('Quote',mongoose.Schema({
    content : {
        type : String,
        required : true
    },
    author : {
        type : String,
        required : true
    },
    designation : {
        type : String,
        required : true
    }
}))

module.exports = Quote