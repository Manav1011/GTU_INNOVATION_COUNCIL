const mongoose = require('mongoose')

const Startup = mongoose.model('Startup',mongoose.Schema({
    title: {
        type: String,
        required : true
    },
    count : {
        type : String,
        required : true
    }
}))

module.exports = Startup