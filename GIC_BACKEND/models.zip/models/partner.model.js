const mongoose = require('mongoose')

const Partner = mongoose.model("Partner",mongoose.Schema({
        logo : {
            type : String,
            required : true,
            default : "img"
        },
        title : {
            type : String,
            required : true
        },
        about : {
            type : String,
            required : true
        }
}))

module.exports = Partner