const mongoose = require('mongoose')

const Incubation = mongoose.model("Incubation",mongoose.Schema({
    candidate_name : {
        type : String,
        requried: true
    },
    email: {
        type : String,
        required : true,
    },
    start_up_name:{
        type : String,
        required : true
    },
    city:{
        type : String,
        required : true
    },
    contact:{
        type:String,
        required : true
    },
    startup_idea:{
        type : String,
        required: true
    },
    description : {
        type : String,
        required : true
    },
    stage : {
        type : String,
        required : true
    },
    like_to_avail : {
        type : String,
        required : true
    },
    another_incubation_center : {
        type : String,
        required: true
    },
    team_size : {
        type : String,
        required : true
    },
    raised_fund : {
        type : Number,
        required : true,
        default : 0
    },
    funding_agency_name : {
        type : String,
        required : true
    },
    attechment : {
        type : String,
        required : true
    }
}))

module.exports = Incubation