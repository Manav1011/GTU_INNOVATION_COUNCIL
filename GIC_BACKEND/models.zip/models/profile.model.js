const mongoose = require('mongoose')

const User = mongoose.model("User",mongoose.Schema({
    user_name : {
        type:String,
        required: true,
    },
    user_email: {
        type: String,
        required:true,
        unique: true
    },
    user_contact: {
        type: String,
        required:true
    },
    user_password:{
        type:String,
        required:true
    },
    session_id: {
        type: String,
    },
    is_session_active : {
        type:Boolean,
        default : false
    }
}))

module.exports = User